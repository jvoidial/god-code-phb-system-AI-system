#!/data/data/com.termux/files/usr/bin/bash
echo "[PortalOpen] Opening PHB portal..."
# Add your portal opening code here
date +"%Y-%m-%d %H:%M:%S" >> ~/gcs/logs/portal_open.log
